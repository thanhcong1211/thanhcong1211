package com.example.quan_ly_phong_thi_nghiem.repository;

import com.example.quan_ly_phong_thi_nghiem.model.Liquidate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ILiquidateRepo extends JpaRepository<Liquidate, Long> {
}
