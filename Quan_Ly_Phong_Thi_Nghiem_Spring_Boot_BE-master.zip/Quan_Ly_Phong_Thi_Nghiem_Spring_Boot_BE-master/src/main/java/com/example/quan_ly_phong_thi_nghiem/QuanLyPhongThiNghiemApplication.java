package com.example.quan_ly_phong_thi_nghiem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyPhongThiNghiemApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuanLyPhongThiNghiemApplication.class, args);
    }

}
