package com.example.quan_ly_phong_thi_nghiem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyPhongThiNghiemApplicationTests {

    @Test
    void contextLoads() {
    }

}
